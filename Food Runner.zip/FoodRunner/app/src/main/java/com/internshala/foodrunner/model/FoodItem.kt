package com.internshala.foodrunner.model

data class FoodItem(val id: String?, val name: String?, val cost: Int?)
